@extends('layouts.app') @section('content') 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
<style>
    .fa-home{
        position: absolute;
        left: -213px;
        top: 90%;
    }
</style>
<div class="container">
    <div class="row align-items-center form-pos">
    <div class="col-12 col-md-6 text-center py-5">
        <a href="{{env('MAIN_APP_URL')}}" class="">
            <img src="{{asset('frontend/Pics/logo.png')}}" height="75%" width="75%" class="img-fluid" alt="logo" />
        </a>
        <a href="https://ya-hub.com/" class="d-block float-left mb-3" style="color: #fd5c29;">
            <i class="fa fa-home fa-2x"></i>
        </a>
    </div>
        <div class="col-12 col-md-6 px-0">
            <div class="form-box p-4">
                <div class="d-flex pt-3 px-md-3">
                    <button class="opt-btn btn w-50">Sign In</button>
                    <button class="opt-btn btn w-50">Sign Up</button>
                </div>
                <div class="content">
                    <div class="ya-form text-white px-md-3 pb-3 content-1 active">
                        <div class="text-center my-4 py-2">
                            <h2>Login to your Ya-Hub account</h2>
                        </div>@if (\Session::has('success')) <div class="alert alert-success"> {!! \Session::get('success') !!} </div> @endif @if (\Session::has('status')) <div class="alert alert-success"> {!! \Session::get('status') !!} </div> @endif @if (\Session::has('error')) <div class="alert alert-danger"> {!! \Session::get('error') !!} </div> @endif @if ($errors->any()) <div class="alert alert-danger"> {!! $errors->first() !!} </div> @endif <form method="POST"
                            action="{{ route('login') }}"> @csrf <div class="form-group">
                                <label class="text-uppercase">email</label>
                                <input type="email"
                                    class="form-control border-0"
                                    name="email"
                                    placeholder="Enter your email" /> @error('email') <div class="alert alert-danger"
                                    role="alert">
                                    <strong>{{ $message }}</strong>
                                </div> @enderror
                            </div>
                            <div class="form-group">
                                <label class="text-uppercase">Password</label>
                                <input type="password"
                                    name="password"
                                    class="form-control border-0"
                                    placeholder="Enter your password  " /> @error('password') <div class="alert alert-danger"
                                    role="alert">
                                    <strong>{{ $message }}</strong>
                                </div> @enderror
                            </div>
                            <div class="d-flex"
                                style="justify-content: space-between;">
                                <div class="text-left">
                                </div>
                                <div class="text-right">
                                    <a href="{{ route('password.request') }}"
                                        class="btn text-white">Forgot Password?</a>
                                </div>
                            </div>
                            <button type="submit"
                                class="btn bg-white w-100 mt-3 s-btn text-uppercase"> Login </button>
                        </form>
                    </div>
                    <div class="ya-form text-white px-3 pb-3 content-2">
                        <div class="text-center my-4 py-2">
                            <h2>Register Your account</h2>
                        </div>
                        <form method="POST"
                            action="{{ route('register') }}"> @csrf <div class="form-group">
                                <label class="text-uppercase">FIRSTNAME - SURNAME</label>
                                <input type="text"
                                    name="name"
                                    class="form-control border-0"
                                    placeholder="Enter your Full Name" /> @error('name') <div class="alert alert-danger"
                                    role="alert">
                                    <strong>{{ $message }}</strong>
                                </div> @enderror
                            </div>
                            <!-- <div class="agency-name-area form-group">
                                <label class="text-uppercase">Agency Contact</label>
                                <input type="text"
                                    name="agency_contact"
                                    class="form-control border-0"
                                    placeholder="Enter Agency Contact" /> @error('name') <div class="alert alert-danger"
                                    role="alert">
                                    <strong>{{ $message }}</strong>
                                </div> @enderror
                            </div> -->
                            <div class="form-group">
                                <label class="text-uppercase">username</label>
                                <input type="text"
                                    name="username"
                                    class="form-control border-0"
                                    placeholder="Enter your username" /> @error('username') <div class="alert alert-danger"
                                    role="alert">
                                    <strong>{{ $message }}</strong>
                                </div> @enderror
                            </div>
                            <div class="form-group">
                                <label class="text-uppercase">email</label>
                                <input type="email"
                                    name="email"
                                    class="form-control border-0"
                                    placeholder="Enter your email" /> @error('email') <div class="alert alert-danger"
                                    role="alert">
                                    <strong>{{ $message }}</strong>
                                </div> @enderror
                            </div>
                            <div class="form-group">
                                <label class="text-uppercase">Password</label>
                                <input type="password"
                                    name="password"
                                    class="form-control border-0"
                                    placeholder="Enter your password" /> @error('password') <div class="alert alert-danger"
                                    role="alert">
                                    <strong>{{ $message }}</strong>
                                </div> @enderror
                            </div>
                            <div class="form-group">
                                <label class="text-uppercase">Account Type</label>
                                <select class="form-control role-toggle border-0"
                                    name="role">
                                    <option value="3">Client</option>
                                    <option value="4">Supplier</option>
                                    <option value="2">Admin</option>
                                </select> @error('role') <div class="alert alert-danger"
                                    role="alert">
                                    <strong>{{ $message }}</strong>
                                </div> @enderror
                            </div>
                            <div class="form-group code-area-agency">
                                <label class="text-uppercase">Enter Code</label>
                                <input type="text"
                                    name="code"
                                    class="form-control border-0"
                                    placeholder="Enter your code" />
                            </div>
                            <div class="form-group form-check">
                                <input type="checkbox"
                                    class="form-check-input terms-agree-btn" />
                                <label class="ml-2">I agree to terms and conditions</label>
                            </div>
                            <div class="d-flex"
                                style="justify-content: space-between;">
                                <div class="text-left">
                                    <a target="_blank"
                                        href="{{env('MAIN_APP_URL').'/terms'}}"
                                        class="btn text-white">
                                        << Terms
                                            and
                                            Conditions</a>
                                </div>
                            </div>
                            <button type="submit"
                                class="btn bg-white w-100 s-btn text-uppercase register-submit"
                                disabled> register </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> @endsection
