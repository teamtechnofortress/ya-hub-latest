 <div class="header border-bottom">
    <style>
        .nav-item{
            padding: 2px 5px;
        }
        .nav-item > a{
            width: 100%;
        }
    </style>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: transparent !important">
        <a class="navbar-brand" href="#">
            @if($logo)
                <img src="{{$logo}}" class="img-fluid" alt="logo" />
            @else
                <img src="{{asset('frontend/Pics/logo.png')}}" class="img-fluid" alt="logo" />
            @endif
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            
          </ul>
          <ul class="navbar-nav">
            <li class="nav-item">
                <a href="{{route('lite-agency-dashboard')}}" class="btn n-project btn-sm"><i class="far fa-arrow-alt-circle-left"></i> Projects</a>
            </li>
            <li class="nav-item">
                <a href="{{route('lite-agency-newproject')}}" class="btn n-project btn-sm">+ New Project</a>
            </li>
            @if(Auth::user()->enable_invoiceTool==1)
            <li class="nav-item">
                <a href="{{route('liteAgency_invoices')}}" class="btn btn-light btn-sm">Invoices</a>
            </li>
            <li class="nav-item">
                <a href="{{route('liteAgency_estimates')}}" class="btn btn-light btn-sm">Estimates</a>
            </li>
            <li class="nav-item">
                <a href="{{route('liteAgency_purchaseOrder')}}" class="btn btn-light btn-sm">Purchase Orders</a>
            </li>
            @endif
            @php 
                $enable_crm = \DB::table('users')->where('id',\Auth::user()->id)->first()->enable_crm;
            @endphp
            @if($enable_crm==1)
            <li class="nav-item">
                <a href="{{url('companies')}}" class="btn btn-light btn-sm">Companies</a>
            </li>
            <li class="nav-item">
                <a href="{{url('contacts')}}" class="btn btn-light btn-sm">Contacts</a>
            </li>
            <li class="nav-item">
                <a href="{{url('tasks')}}" class="btn btn-light btn-sm">Tasks</a>
            </li>
            @endif
            @if(Auth::user()->bookkeepingTool==1)
            <li class="nav-item">
                <a href="{{url('bookkeeping')}}" class="btn btn-light btn-sm">Bookkeeping</a>
            </li>
            @endif
            <li class="nav-item">
                <a href="{{url('logout')}}" class="btn btn-secondary btn-sm"><i class="fa fa-sign-out"></i></a>
            </li>
          </ul>
        </div>
    </nav>
 </div>
<div>

