<div class="border-top d-flex d-sm-none justify-content-around bg-white w-100 mobile-nav bg-white">
    <div>
        <a href="{{route('admin-dashboard')}}"
            class="btn nav-active"><i class="fas fa-tachometer-alt"></i></a>
    </div>
    <div>
        <a href="{{route('lite_agecnies')}}"
            class="btn"><i class="fas fa-bolt"></i></a>
    </div>
    <div>
        <a href="{{route('admin-clients')}}"
            class="btn"><i class="fas fa-users"></i></a>
    </div>
    <div>
        <a href="{{route('admin-projects')}}"
            class="btn"><i class="fas fa-file-alt"></i></a>
    </div>
    <div>
        <a href="{{route('admin-settings')}}"
            class="btn"><i class="fas fa-cogs"></i></a>
    </div>
</div>
