<div class="side-nav text-center border-right d-sm-flex d-none flex-column justify-content-around position-fixed">
    <div class="my-4">
        <a href="{{route('admin-dashboard')}}"
            class="btn nav-active"><i class="fas fa-2x fa-tachometer-alt"></i></a>
    </div>
    <div class="my-4">
        <a href="{{route('lite_agecnies')}}"
            class="btn"><i class="fas fa-2x fa-bolt"></i></a>
    </div>
    <div class="my-4">
        <a href="{{route('admin-clients')}}"
            class="btn"><i class="fas fa-2x fa-users"></i></a>
    </div>
    <div class="my-4">
        <a href="{{route('admin-projects')}}"
            class="btn"><i class="fas fa-2x fa-file-alt"></i></a>
    </div>
    <div class="my-4">
        <a href="{{route('admin-settings')}}"
            class="btn"><i class="fas fa-2x fa-cogs"></i></a>
    </div>
</div>
